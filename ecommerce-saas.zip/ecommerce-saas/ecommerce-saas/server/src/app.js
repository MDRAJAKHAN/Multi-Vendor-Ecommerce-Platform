import express from 'express'
import cors from 'cors'

import authRoutes from './routes/authRoutes.js'
import productRoutes from './routes/productRoutes.js'
import orderRoutes from './routes/orderRoutes.js'
import paymentRoutes from './routes/paymentRoutes.js'
import reviewRoutes from './routes/reviewRoutes.js'
import categoryRoutes from './routes/categoryRoutes.js'
import couponRoutes from './routes/couponRoutes.js'
import adminRoutes from './routes/adminRoutes.js'

import errorMiddleware from './middleware/errorMiddleware.js'

const app = express()

app.use(cors())

app.use(express.json())

app.use('/api/auth', authRoutes)

app.use('/api/products', productRoutes)

app.use('/api/orders', orderRoutes)

app.use('/api/payments', paymentRoutes)

app.use('/api/reviews', reviewRoutes)

app.use('/api/categories', categoryRoutes)

app.use('/api/coupons', couponRoutes)

app.use('/api/admin', adminRoutes)

app.use(errorMiddleware)

export default app