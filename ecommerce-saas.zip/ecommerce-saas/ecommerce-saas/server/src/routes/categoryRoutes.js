import express from 'express'

import authMiddleware from '../middleware/authMiddleware.js'

import adminMiddleware from '../middleware/adminMiddleware.js'

import {
  createCategory,
  getCategories,
} from '../controllers/categoryController.js'

const router = express.Router()

router.get('/', getCategories)

router.post(
  '/',
  authMiddleware,
  adminMiddleware,
  createCategory
)

export default router