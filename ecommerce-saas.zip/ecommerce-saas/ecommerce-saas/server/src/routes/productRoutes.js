import express from 'express'

import authMiddleware from '../middleware/authMiddleware.js'
import sellerMiddleware from '../middleware/sellerMiddleware.js'

import {
  createProduct,
  getProducts,
  getSingleProduct,
  deleteProduct,
} from '../controllers/productController.js'

const router = express.Router()

router.get('/', getProducts)

router.get('/:id', getSingleProduct)

router.post(
  '/',
  authMiddleware,
  sellerMiddleware,
  createProduct
)

router.delete(
  '/:id',
  authMiddleware,
  sellerMiddleware,
  deleteProduct
)

export default router