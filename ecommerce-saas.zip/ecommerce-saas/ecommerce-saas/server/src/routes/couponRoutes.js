import express from 'express'

import authMiddleware from '../middleware/authMiddleware.js'

import adminMiddleware from '../middleware/adminMiddleware.js'

import {
  createCoupon,
  applyCoupon,
} from '../controllers/couponController.js'

const router = express.Router()

router.post(
  '/',
  authMiddleware,
  adminMiddleware,
  createCoupon
)

router.post('/apply', applyCoupon)

export default router