// File: server/src/routes/authRoutes.js
import express from 'express';
import {
  registerUser,
  loginUser,
  sendOtp,        // <-- NEW
  resetPassword,  // <-- NEW
} from '../controllers/authController.js';

const router = express.Router();

router.post('/register', registerUser);
router.post('/login', loginUser);

// --- NEW OTP ROUTES ---
router.post('/send-otp', sendOtp);
router.post('/reset-password', resetPassword);

export default router;