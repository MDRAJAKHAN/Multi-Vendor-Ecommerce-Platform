import express from 'express'

import authMiddleware from '../middleware/authMiddleware.js'

import { processPayment } from '../controllers/paymentController.js'

const router = express.Router()

router.post(
  '/',
  authMiddleware,
  processPayment
)

export default router