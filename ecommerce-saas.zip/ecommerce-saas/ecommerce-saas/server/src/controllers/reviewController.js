import Review from '../models/Review.js'

export const createReview = async (
  req,
  res
) => {
  try {
    const review = await Review.create({
      ...req.body,
      user: req.user._id,
    })

    res.status(201).json(review)
  } catch (error) {
    res.status(500).json({
      message: error.message,
    })
  }
}