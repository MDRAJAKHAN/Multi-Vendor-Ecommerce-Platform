import bcrypt from 'bcryptjs'
import User from '../models/User.js'
import generateToken from '../utils/generateToken.js'
import { sendEmail } from '../services/emailService.js'; // Real email sender!

export const registerUser = async (req, res) => {
  try {
    const { name, email, password } = req.body

    const userExists = await User.findOne({ email })

    if (userExists) {
      return res.status(400).json({ message: 'User already exists' })
    }

    const hashedPassword = await bcrypt.hash(password, 10)

    const user = await User.create({
      name,
      email,
      password: hashedPassword,
    })

    res.status(201).json({
      message: 'User registered successfully',
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role
      },
      token: generateToken(user._id)
    })
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
}

export const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body

    const user = await User.findOne({ email })

    if (!user) {
      return res.status(400).json({ message: 'Invalid credentials' })
    }

    const isMatch = await bcrypt.compare(password, user.password)

    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' })
    }

    res.json({
      token: generateToken(user._id),
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role
      },
    })
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
}

// --- SEND OTP FUNCTION (NOW WITH REAL EMAIL!) ---
export const sendOtp = async (req, res) => {
  try {
    const { email } = req.body;

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ message: "No account found with this email." });
    }

    // 1. Generate a random 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    // 2. Save the OTP and set it to expire in 15 minutes
    user.resetPasswordOtp = otp;
    user.resetPasswordExpires = Date.now() + 15 * 60 * 1000; 
    await user.save();

    // 3. Send the REAL email to the user!
    const emailHtml = `
      <div style="font-family: Arial, sans-serif; text-align: center; padding: 20px;">
        <h2>Password Reset Request</h2>
        <p>You requested to reset your password. Use the code below to securely verify your identity:</p>
        <h1 style="font-size: 40px; letter-spacing: 5px; color: #3b82f6; background: #f3f4f6; padding: 10px; border-radius: 10px; display: inline-block;">${otp}</h1>
        <p style="color: gray; font-size: 12px;">This code expires in 15 minutes. If you didn't request this, please ignore this email.</p>
      </div>
    `;

    await sendEmail({
      to: user.email,
      subject: 'Your Password Reset Security Code',
      html: emailHtml
    });

    res.status(200).json({ message: "OTP sent successfully." });

  } catch (error) {
    console.error("OTP Error:", error);
    res.status(500).json({ message: "Failed to send email. Check server logs." });
  }
};

// --- RESET PASSWORD FUNCTION ---
export const resetPassword = async (req, res) => {
  try {
    const { email, otp, newPassword } = req.body;

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ message: "User not found." });
    }

    // Check if OTP matches and is not expired
    if (user.resetPasswordOtp !== otp) {
      return res.status(400).json({ message: "Invalid OTP code." });
    }
    
    if (user.resetPasswordExpires < Date.now()) {
      return res.status(400).json({ message: "OTP has expired. Please request a new one." });
    }

    // Hash the new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;

    // Clear the OTP fields so they can't be reused
    user.resetPasswordOtp = undefined;
    user.resetPasswordExpires = undefined;
    await user.save();

    res.status(200).json({ message: "Password reset successful." });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};