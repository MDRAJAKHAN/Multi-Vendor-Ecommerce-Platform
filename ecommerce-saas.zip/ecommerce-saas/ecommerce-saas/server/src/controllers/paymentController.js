export const processPayment = async (
  req,
  res
) => {
  try {
    res.json({
      success: true,
      message: 'Payment Successful',
    })
  } catch (error) {
    res.status(500).json({
      message: error.message,
    })
  }
}