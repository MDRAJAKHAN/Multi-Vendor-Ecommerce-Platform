import Coupon from '../models/Coupon.js'

export const createCoupon = async (
  req,
  res
) => {
  try {
    const coupon = await Coupon.create(
      req.body
    )

    res.status(201).json(coupon)
  } catch (error) {
    res.status(500).json({
      message: error.message,
    })
  }
}

export const applyCoupon = async (
  req,
  res
) => {
  try {
    const { code } = req.body

    const coupon = await Coupon.findOne({
      code,
    })

    if (!coupon) {
      return res.status(404).json({
        message: 'Coupon not found',
      })
    }

    res.json(coupon)
  } catch (error) {
    res.status(500).json({
      message: error.message,
    })
  }
}