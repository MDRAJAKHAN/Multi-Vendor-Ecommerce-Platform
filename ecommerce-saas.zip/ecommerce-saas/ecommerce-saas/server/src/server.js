import dotenv from 'dotenv'
import mongoose from 'mongoose'
import app from './app.js'

dotenv.config()

// 1. Use the port from .env, or default to 5002 to avoid the port 5000 conflict
const PORT = process.env.PORT || 5002;

mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log('MongoDB Connected ✅')

    app.listen(PORT, () => {
      console.log(`Server Running on Port ${PORT} 🚀`)
    })
  })
  .catch((error) => {
    console.log('Database connection error:', error)
  })