import nodemailer from 'nodemailer';

export const sendEmail = async (options) => {
  try {
    // 1. Create a transporter (The "Mail Truck")
    const transporter = nodemailer.createTransport({
      service: 'gmail', // We are using Gmail for testing
      auth: {
        user: process.env.EMAIL_USERNAME, 
        pass: process.env.EMAIL_PASSWORD, // IMPORTANT: This must be an App Password, not your normal password!
      },
    });

    // 2. Define the email options (The "Envelope")
    const mailOptions = {
      from: `E-Commerce SaaS <${process.env.EMAIL_USERNAME}>`,
      to: options.to,
      subject: options.subject,
      html: options.html, // Using HTML so we can make it look pretty!
    };

    // 3. Send the email
    await transporter.sendMail(mailOptions);
    console.log(`Email successfully sent to ${options.to}`);

  } catch (error) {
    console.error("Error sending email:", error);
    throw new Error("Email could not be sent");
  }
};