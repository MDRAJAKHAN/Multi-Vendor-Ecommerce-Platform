export const paymentService = async (
  amount
) => {
  return {
    success: true,
    amount,
  }
}