const razorpayConfig = () => {
  console.log('Razorpay Config Ready')
}

export default razorpayConfig