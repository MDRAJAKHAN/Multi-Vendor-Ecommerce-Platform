const cloudinaryConfig = () => {
  console.log('Cloudinary Config Ready')
}

export default cloudinaryConfig