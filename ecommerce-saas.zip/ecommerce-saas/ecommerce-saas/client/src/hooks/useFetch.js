import { useEffect, useState } from 'react';

const useFetch = (apiFunction) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const result = await apiFunction();
        setData(result.data); // Assuming axios returns an object with a 'data' property
        setLoading(false);
      } catch (err) {
        setError(err);
        setLoading(false);
      }
    };
    fetchData();
  }, [apiFunction]); // Include apiFunction as a dependency

  return { data, loading, error };
};

export default useFetch;