import AppRoutes from './routes/AppRoutes';
import { Toaster } from 'react-hot-toast';
import CartDrawer from './components/common/CartDrawer';

function App() {
  return (
    <div className="relative min-h-screen text-white font-sans selection:bg-blue-500 selection:text-white overflow-hidden">
      
      {/* --- THE PRO BACKGROUND --- */}
      <div className="fixed inset-0 z-[-1] bg-gray-950 overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[50vw] h-[50vw] rounded-full bg-blue-600/20 blur-[120px] mix-blend-screen animate-blob" />
        <div className="absolute top-[20%] right-[-10%] w-[40vw] h-[40vw] rounded-full bg-purple-600/20 blur-[120px] mix-blend-screen animate-blob animation-delay-2000" />
        <div className="absolute bottom-[-20%] left-[20%] w-[60vw] h-[60vw] rounded-full bg-emerald-600/10 blur-[120px] mix-blend-screen animate-blob animation-delay-4000" />
      </div>

      {/* --- THE TOASTER --- */}
      <Toaster 
        position="bottom-right"
        toastOptions={{
          style: {
            background: '#1f2937', 
            color: '#fff',
            border: '1px solid rgba(255,255,255,0.05)',
            borderRadius: '12px',
            backdropFilter: 'blur(10px)',
          },
          success: { iconTheme: { primary: '#3b82f6', secondary: '#fff' } },
        }}
      />

      {/* --- THE SLIDE-OUT CART --- */}
      <CartDrawer />

      {/* --- YOUR ROUTES --- */}
      <AppRoutes />
    </div>
  );
}

export default App;