import API from './axios'

export const paymentAPI = async () => {
  const { data } = await API.post(
    '/payments'
  )

  return data
}