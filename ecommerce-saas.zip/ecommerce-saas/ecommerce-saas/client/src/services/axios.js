import axios from 'axios';

// Replace 5000 with whatever port your Node server is running on!
const API = axios.create({
  baseURL: 'http://localhost:5000/api', 
});

// Automatically attach the JWT token if the user is logged in
API.interceptors.request.use((req) => {
  const token = localStorage.getItem('token'); // Or wherever you store it
  if (token) {
    req.headers.Authorization = `Bearer ${token}`;
  }
  return req;
});

export default API;