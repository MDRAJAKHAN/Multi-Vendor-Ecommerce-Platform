import API from './axios'

export const getProducts = async () => {
  const { data } = await API.get('/products')

  return data
}

export const getProduct = async (id) => {
  const { data } = await API.get(
    `/products/${id}`
  )

  return data
}