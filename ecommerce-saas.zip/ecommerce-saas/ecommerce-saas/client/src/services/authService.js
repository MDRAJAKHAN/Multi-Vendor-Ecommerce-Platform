import API from './axios'

export const getProfile = async () => {
  const { data } = await API.get('/auth/profile')

  return data
}