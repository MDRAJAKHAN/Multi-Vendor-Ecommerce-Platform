// File: src/data/mockProducts.js

export const mockProducts = [
  // --- ELECTRONICS ---
  { _id: "e1", title: "Premium Wireless Headphones", price: 12000, category: "Electronics", image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&q=80" },
  { _id: "e2", title: "Apple Watch Series 9", price: 42000, category: "Electronics", image: "https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=600&q=80" },
  { _id: "e3", title: "Sony Mirrorless Camera", price: 85000, category: "Electronics", image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=600&q=80" },
  { _id: "e4", title: "MacBook Pro M3", price: 145000, category: "Electronics", image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=600&q=80" },
  { _id: "e5", title: "Bluetooth Smart Speaker", price: 4500, category: "Electronics", image: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=600&q=80" },
  { _id: "e6", title: "4K Drone with Gimbal", price: 65000, category: "Electronics", image: "https://images.unsplash.com/photo-1473968512647-3e447244af8f?w=600&q=80" },
  { _id: "e7", title: "Noise Cancelling Earbuds", price: 8900, category: "Electronics", image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=600&q=80" },
  {  _id: "new_e1", title: "Ultra-Slim 4K OLED TV", price: 125000, category: "Electronics", image: "https://images.unsplash.com/photo-1593640408182-31c70c8268f5?w=600&q=80"  },
  // --- CLOTHING ---
  { _id: "c1", title: "Minimalist Cotton T-Shirt", price: 1500, category: "Clothing", image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&q=80" },
  { _id: "c2", title: "Classic Denim Jacket", price: 3500, category: "Clothing", image: "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=600&q=80" },
  { _id: "c3", title: "Nike Air Max Sneakers", price: 9500, category: "Clothing", image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&q=80" },
  { _id: "c4", title: "Polarized Sunglasses", price: 2200, category: "Clothing", image: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=600&q=80" },
  { _id: "c5", title: "Vintage Leather Watch", price: 5500, category: "Clothing", image: "https://images.unsplash.com/photo-1524592094714-a57ee1ce4248?w=600&q=80" },
  { _id: "c6", title: "Urban Streetwear Hoodie", price: 2800, category: "Clothing", image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=600&q=80" },
  { _id: "c7", title: "Waterproof Hiking Boots", price: 6200, category: "Clothing", image: "https://images.unsplash.com/photo-1520639887900-8462098f6cb7?w=600&q=80" },
  {  _id: "new_c1", title: "Waterproof Winter Parka", price: 8500, category: "Clothing", image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=600&q=80"  },
  // --- HOME ---
  { _id: "h1", title: "Modern Desk Lamp", price: 2500, category: "Home", image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=600&q=80" },
  { _id: "h2", title: "Ceramic Coffee Mug", price: 800, category: "Home", image: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=600&q=80" },
  { _id: "h3", title: "Velvet Lounge Sofa", price: 34000, category: "Home", image: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=600&q=80" },
  { _id: "h4", title: "Indoor Potted Plant", price: 900, category: "Home", image: "https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=600&q=80" },
  { _id: "h5", title: "Luxury Scented Candle", price: 1200, category: "Home", image: "https://images.unsplash.com/photo-1603006905003-be475563bc59?w=600&q=80" },
  { _id: "h6", title: "Geometric Area Rug", price: 4500, category: "Home", image: "https://images.unsplash.com/photo-1534889156217-d643df14f14a?w=600&q=80" },
  { _id: "h7", title: "Minimalist Wall Clock", price: 1800, category: "Home", image: "https://images.unsplash.com/photo-1563861826100-9cb868fdbe1c?w=600&q=80" },
  {  _id: "new_h1", title: "Smart Espresso Machine", price: 22000, category: "Home",  image: "https://images.unsplash.com/photo-1556228453-efd6c1ff04f6?w=600&q=80"  },
  // --- BOOKS ---
  { _id: "b1", title: "The Art of War - Sun Tzu", price: 450, category: "Books", image: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=600&q=80" },
  { _id: "b2", title: "Atomic Habits - James Clear", price: 550, category: "Books", image: "https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=600&q=80" },
  { _id: "b3", title: "Design Thinking Handbook", price: 1200, category: "Books", image: "https://images.unsplash.com/photo-1618666012174-83b441c0bc76?w=600&q=80" },
  { _id: "b4", title: "Clean Code - Robert C. Martin", price: 1800, category: "Books", image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=600&q=80" },
  { _id: "b5", title: "The Pragmatic Programmer", price: 2100, category: "Books", image: "https://images.unsplash.com/photo-1532012197267-da84d127e765?w=600&q=80" },
  { _id: "b6", title: "Steal Like an Artist", price: 800, category: "Books", image: "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=600&q=80" },
  { _id: "b7", title: "Deep Work - Cal Newport", price: 650, category: "Books", image: "https://images.unsplash.com/photo-1456406644174-8ddd4cd52a06?w=600&q=80" },
  {_id: "new_b1", title: "Thinking, Fast and Slow", price: 750, category: "Books",  image: "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=600&q=80" },
  // --- GAMING ---
  { _id: "g1", title: "Mechanical Keyboard PRO", price: 8500, category: "Gaming", image: "https://images.unsplash.com/photo-1595225476474-87563907a212?w=600&q=80" },
  { _id: "g2", title: "Next-Gen Console Controller", price: 6000, category: "Gaming", image: "https://images.unsplash.com/photo-1600080972464-8e5f35f63d08?w=600&q=80" },
  { _id: "g3", title: "Ergonomic Gaming Chair", price: 18500, category: "Gaming", image: "https://images.unsplash.com/photo-1598550476439-6847785fcea6?w=600&q=80" },
  { _id: "g4", title: "Ultra-Wide Gaming Monitor", price: 42000, category: "Gaming", image: "https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=600&q=80" },
  { _id: "g5", title: "RGB Studio Microphone", price: 11000, category: "Gaming", image: "https://images.unsplash.com/photo-1590602847861-f357a9332bbc?w=600&q=80" },
  { _id: "g6", title: "Precision Gaming Mouse", price: 4500, category: "Gaming", image: "https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?w=600&q=80" },
  { _id: "g7", title: "Virtual Reality Headset", price: 32000, category: "Gaming", image: "https://images.unsplash.com/photo-1622979135225-d2ba269cf1ac?w=600&q=80" },
  { _id: "new_g1", title: "Dual Monitor Streaming Setup", price: 65000, category: "Gaming", image: "https://images.unsplash.com/photo-1598550476439-6847785fcea6?w=600&q=80"  },
  // --- FITNESS ---
  { _id: "f1", title: "Adjustable Dumbbell Set", price: 15000, category: "Fitness", image: "https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?w=600&q=80" },
  { _id: "f2", title: "Non-Slip Yoga Mat", price: 1200, category: "Fitness", image: "https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=600&q=80" },
  { _id: "f3", title: "Stainless Steel Protein Shaker", price: 950, category: "Fitness", image: "https://images.unsplash.com/photo-1574888022415-430c6a524a8f?w=600&q=80" },
  { _id: "f4", title: "Resistance Band Set", price: 1800, category: "Fitness", image: "https://images.unsplash.com/photo-1598266663412-7bbc9f3730e7?w=600&q=80" },
  { _id: "f5", title: "Foam Roller Pro", price: 1100, category: "Fitness", image: "https://images.unsplash.com/photo-1518611012118-696072aa579a?w=600&q=80" },
  { _id: "f6", title: "Jump Rope with Counter", price: 600, category: "Fitness", image: "https://images.unsplash.com/photo-1434682772747-f16d3ea162c3?w=600&q=80" },
  { _id: "f7", title: "Premium Kettlebell (16kg)", price: 3500, category: "Fitness", image: "https://images.unsplash.com/photo-1526506159987-251f2f819446?w=600&q=80" },
  {_id: "new_f1", title: "Heavy Duty Gym Weights", price: 4500, category: "Fitness", image: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=600&q=80" }
];