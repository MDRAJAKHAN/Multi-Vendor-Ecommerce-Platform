import { Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';

// Layouts & Guards
import MainLayout from '../layouts/MainLayout';
import PrivateRoute from './PrivateRoute';

// Pages
import Home from '../pages/customer/Home';
import Shop from '../pages/customer/Shop';
import Cart from '../pages/shop/Cart';
import ProductDetails from '../pages/shop/ProductDetails';
import Login from '../pages/auth/Login';
import Register from '../pages/auth/Register';
import ForgotPassword from '../pages/auth/ForgotPassword';
import Dashboard from '../pages/vendor/Dashboard';
import Orders from '../pages/customer/Orders';

// <-- 1. IMPORT YOUR NEW CHECKOUT COMPONENT HERE -->
import Checkout from '../pages/customer/Checkout'; 

const AppRoutes = () => {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        
        <Route element={<MainLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/product/:id" element={<ProductDetails />} />
          <Route path="/cart" element={<Cart />} />
          
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          
          <Route path="/dashboard" element={<Dashboard />} />
          
          <Route element={<PrivateRoute />}>
            <Route path="/orders" element={<Orders />} />
            
            {/* <-- 2. REPLACE THE PLACEHOLDER WITH THE REAL COMPONENT --> */}
            <Route path="/checkout" element={<Checkout />} />
            
          </Route>
        </Route>

      </Routes>
    </AnimatePresence>
  );
};

export default AppRoutes;