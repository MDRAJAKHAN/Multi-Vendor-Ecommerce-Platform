// File: src/routes/AdminRoute.jsx
import { Navigate, Outlet } from 'react-router-dom';
import { useSelector } from 'react-redux';

const AdminRoute = () => {
  const { isAuthenticated, user } = useSelector((state) => state.auth);

  // Must be logged in AND have the role of 'admin'
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (user?.role !== 'admin') return <Navigate to="/" replace />; // Kick to home if not admin

  return <Outlet />;
};

export default AdminRoute;