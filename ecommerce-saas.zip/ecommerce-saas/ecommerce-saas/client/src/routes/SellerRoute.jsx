import { Navigate } from 'react-router-dom'

import useAuth from '../hooks/useAuth'

const SellerRoute = ({ children }) => {
  const { user } = useAuth()

  return user?.role === 'seller' ? (
    children
  ) : (
    <Navigate to='/' />
  )
}

export default SellerRoute