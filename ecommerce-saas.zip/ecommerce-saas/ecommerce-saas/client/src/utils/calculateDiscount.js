const calculateDiscount = (
  originalPrice,
  discountPrice
) => {
  return Math.round(
    ((originalPrice - discountPrice) /
      originalPrice) *
      100
  )
}

export default calculateDiscount