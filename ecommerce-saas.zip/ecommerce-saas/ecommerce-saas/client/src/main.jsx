import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx';
import './index.css';

// 1. IMPORT THE BROWSER ROUTER
import { BrowserRouter } from 'react-router-dom';
// Keep your Redux Provider import if you have one!
import { Provider } from 'react-redux'; 
import { store } from './app/store.js';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Provider store={store}>
      {/* 2. WRAP YOUR APP IN THE BROWSER ROUTER! */}
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </Provider>
  </React.StrictMode>,
);