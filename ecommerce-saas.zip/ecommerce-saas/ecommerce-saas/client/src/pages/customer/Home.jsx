import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { FiArrowRight, FiShoppingBag, FiUsers, FiTrendingUp } from 'react-icons/fi';

const Home = () => {
  return (
    <div className="relative min-h-screen flex flex-col justify-center items-center overflow-hidden pt-20 px-6">
      
      {/* --- BACKGROUND ABSTRACT UI ELEMENTS --- */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        {/* Floating Card 1: Vendors */}
        <motion.div 
          animate={{ y: [0, -20, 0], rotate: [0, 5, 0] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          className="hidden lg:flex absolute top-32 left-[10%] w-64 h-40 bg-white/[0.02] border border-white/5 backdrop-blur-md rounded-2xl p-6 flex-col justify-between shadow-2xl"
        >
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400">
              <FiUsers size={20} />
            </div>
            <div>
              <div className="h-2 w-20 bg-gray-700 rounded-full mb-2"></div>
              <div className="h-2 w-12 bg-gray-800 rounded-full"></div>
            </div>
          </div>
          <div className="flex gap-2">
            <div className="h-8 flex-1 bg-white/[0.05] rounded-lg"></div>
            <div className="h-8 flex-1 bg-white/[0.05] rounded-lg"></div>
          </div>
        </motion.div>

        {/* Floating Card 2: Sales / Analytics */}
        <motion.div 
          animate={{ y: [0, 30, 0], rotate: [0, -3, 0] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          className="hidden lg:flex absolute bottom-32 right-[10%] w-72 h-48 bg-white/[0.02] border border-white/5 backdrop-blur-md rounded-2xl p-6 flex-col gap-4 shadow-2xl"
        >
          <div className="flex items-center justify-between">
            <div className="h-3 w-24 bg-gray-700 rounded-full"></div>
            <FiTrendingUp className="text-emerald-400" size={20} />
          </div>
          <div className="flex items-end gap-2 h-full pt-4">
            {[40, 70, 45, 90, 65].map((height, i) => (
              <div key={i} className="flex-1 bg-blue-500/20 rounded-t-sm" style={{ height: `${height}%` }}></div>
            ))}
          </div>
        </motion.div>

        {/* Floating Card 3: Products */}
        <motion.div 
          animate={{ y: [0, -15, 0], x: [0, 10, 0] }}
          transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 2 }}
          className="hidden md:flex absolute top-40 right-[20%] w-16 h-16 bg-white/[0.02] border border-white/5 backdrop-blur-md rounded-2xl items-center justify-center text-purple-400 shadow-2xl"
        >
          <FiShoppingBag size={24} />
        </motion.div>
      </div>

      {/* --- FOREGROUND CONTENT --- */}
      <div className="relative z-10 text-center max-w-4xl mx-auto flex flex-col items-center">
        
        {/* Animated Badge */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 text-sm text-blue-300 font-medium mb-8 backdrop-blur-md"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
          </span>
          MRKHAN v2.0
        </motion.div>

        {/* Massive Headline */}
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tight mb-6 leading-tight"
        >
          Multi Vendor <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-400">
            E-Commerce SaaS
          </span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="text-lg md:text-2xl text-gray-400 max-w-2xl mb-12 font-light"
        >
          Build scalable, highly-performant modern e-commerce platforms using the full power of the MERN stack.
        </motion.p>

        {/* Call to Action Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <Link 
            to="/shop" 
            className="group relative inline-flex items-center justify-center gap-3 px-8 py-4 bg-white text-gray-950 font-bold rounded-2xl text-lg transition-all hover:scale-105 active:scale-95 shadow-[0_0_40px_-10px_rgba(255,255,255,0.3)] hover:shadow-[0_0_60px_-15px_rgba(255,255,255,0.5)] overflow-hidden"
          >
            {/* Button Shine Effect */}
            <div className="absolute inset-0 -translate-x-full group-hover:animate-[shimmer_1.5s_infinite] bg-gradient-to-r from-transparent via-white/40 to-transparent z-10"></div>
            
            <span className="relative z-20">Explore Store</span>
            <FiArrowRight className="relative z-20 group-hover:translate-x-1 transition-transform" />
          </Link>
        </motion.div>
      </div>

    </div>
  );
};

export default Home;