import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiCreditCard, FiLock, FiCheckCircle, FiSmartphone } from 'react-icons/fi';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { clearCart } from '../../features/cart/cartSlice';
import { addOrder } from '../../features/orders/orderSlice';
import toast from 'react-hot-toast';

const Checkout = () => {
  const { cartItems } = useSelector((state) => state.cart);
  const { isAuthenticated } = useSelector((state) => state.auth); 
  const dispatch = useDispatch();
  const navigate = useNavigate();
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('card'); // 'card' or 'upi'

  const cartTotal = cartItems.reduce((total, item) => total + (Number(item?.price) || 0) * (Number(item?.cartQuantity) || 1), 0);
  const shipping = cartTotal > 5000 ? 0 : 500;
  const grandTotal = cartTotal + shipping;

  useEffect(() => {
    if (!isAuthenticated) {
      toast.error("Please login to proceed to checkout!");
      navigate('/login');
    }
  }, [isAuthenticated, navigate]);

  const handlePayment = (e) => {
    e.preventDefault();
    setIsProcessing(true);

    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
      
      const newOrder = {
        id: `ORD-${Math.floor(Math.random() * 90000) + 10000}`,
        date: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
        total: grandTotal,
        status: "Processing",
        items: [...cartItems],
        paymentMethod: paymentMethod.toUpperCase() 
      };

      dispatch(addOrder(newOrder));
      dispatch(clearCart());
      
      setTimeout(() => navigate('/orders'), 3000);
    }, 2000);
  };

  if (!isAuthenticated) return null;

  if (isSuccess) {
    return (
      <div className="min-h-screen pt-32 flex flex-col items-center justify-center text-center px-6 relative z-10">
        <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-emerald-400 mb-6">
          <FiCheckCircle size={80} />
        </motion.div>
        <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-4xl font-black text-white mb-4">
          Payment Successful!
        </motion.h1>
        <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="text-gray-400 text-lg">
          Your order has been placed securely. Redirecting to your dashboard...
        </motion.p>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-32 px-6 pb-20 max-w-7xl mx-auto text-white relative z-10">
      <div className="mb-12">
        <h1 className="text-4xl font-black tracking-tight mb-2">Secure Checkout</h1>
        <p className="text-gray-400 flex items-center gap-2">
          <FiLock className="text-emerald-400" /> 256-bit SSL Encrypted Payment
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        
        {/* LEFT COLUMN: PAYMENT FORM */}
        <div className="lg:col-span-7 space-y-8">
          <form onSubmit={handlePayment} className="bg-gray-900/50 backdrop-blur-xl border border-white/10 rounded-3xl p-8 shadow-2xl">
            
            <h2 className="text-xl font-bold text-white mb-6">Shipping Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              <input type="text" required placeholder="First Name" className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-blue-500" />
              <input type="text" required placeholder="Last Name" className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-blue-500" />
              <input type="text" required placeholder="Street Address" className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-blue-500 md:col-span-2" />
              <input type="text" required placeholder="City" className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-blue-500" />
              <input type="text" required placeholder="PIN Code" className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-blue-500" />
            </div>

            <h2 className="text-xl font-bold text-white mb-6">Payment Method</h2>
            
            {/* PAYMENT TOGGLE */}
            <div className="flex gap-4 mb-6">
              <button 
                type="button"
                onClick={() => setPaymentMethod('card')}
                className={`flex-1 flex items-center justify-center gap-2 py-4 rounded-xl font-bold transition-all border ${
                  paymentMethod === 'card' 
                  ? 'bg-blue-600/20 border-blue-500 text-blue-400' 
                  : 'bg-white/5 border-white/10 text-gray-400 hover:bg-white/10'
                }`}
              >
                <FiCreditCard size={20} /> Credit / Debit Card
              </button>
              <button 
                type="button"
                onClick={() => setPaymentMethod('upi')}
                className={`flex-1 flex items-center justify-center gap-2 py-4 rounded-xl font-bold transition-all border ${
                  paymentMethod === 'upi' 
                  ? 'bg-blue-600/20 border-blue-500 text-blue-400' 
                  : 'bg-white/5 border-white/10 text-gray-400 hover:bg-white/10'
                }`}
              >
                <FiSmartphone size={20} /> UPI (GPay/PhonePe)
              </button>
            </div>

            {/* CONDITIONAL PAYMENT INPUTS */}
            <AnimatePresence mode="wait">
              {paymentMethod === 'card' ? (
                <motion.div 
                  key="card"
                  initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
                  className="space-y-4 mb-8 overflow-hidden"
                >
                  <input type="text" required placeholder="Cardholder Name" className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-blue-500" />
                  <input type="text" required maxLength="16" placeholder="Card Number (0000 0000 0000 0000)" className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-blue-500 font-mono" />
                  <div className="grid grid-cols-2 gap-4">
                    <input type="text" required placeholder="MM/YY" className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-blue-500 font-mono" />
                    <input type="password" required maxLength="3" placeholder="CVV" className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-blue-500 font-mono" />
                  </div>
                </motion.div>
              ) : (
                <motion.div 
                  key="upi"
                  initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
                  className="space-y-4 mb-8 overflow-hidden"
                >
                  <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-xl mb-4">
                    <p className="text-sm text-blue-400">Please enter your UPI ID. A payment request will be sent to your UPI app.</p>
                  </div>
                  <input type="text" required placeholder="Enter UPI ID (e.g. name@okicici)" className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-blue-500" />
                </motion.div>
              )}
            </AnimatePresence>

            <button 
              type="submit" 
              disabled={isProcessing || cartItems.length === 0}
              className="w-full py-4 bg-blue-600 hover:bg-blue-500 disabled:bg-gray-700 disabled:cursor-not-allowed text-white font-bold rounded-xl transition-all shadow-[0_0_20px_rgba(59,130,246,0.3)] flex justify-center items-center gap-2"
            >
              {isProcessing ? (
                <span className="animate-pulse">Processing Payment...</span>
              ) : (
                <>Pay ₹{grandTotal.toLocaleString('en-IN')}</>
              )}
            </button>
          </form>
        </div>

        {/* RIGHT COLUMN: ORDER SUMMARY */}
        <div className="lg:col-span-5">
          <div className="bg-gray-900/50 backdrop-blur-xl border border-white/10 rounded-3xl p-8 sticky top-28">
            <h2 className="text-xl font-bold text-white mb-6">Order Summary</h2>
            
            <div className="space-y-4 mb-6 max-h-[40vh] overflow-y-auto pr-2">
              {cartItems.length === 0 ? (
                <p className="text-gray-400">Your cart is empty.</p>
              ) : (
                /* THE FIX IS HERE: using (item, index) and key={item?._id || index} */
                cartItems.map((item, index) => (
                  <div key={item?._id || index} className="flex gap-4 items-center">
                    <div className="w-16 h-16 rounded-lg bg-gray-800 flex-shrink-0 overflow-hidden border border-white/5">
                      <img src={item?.image} alt={item?.title} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-sm font-medium text-white line-clamp-1">{item?.title || 'Product'}</h4>
                      <p className="text-xs text-gray-400">Qty: {item?.cartQuantity || 1}</p>
                    </div>
                    <p className="text-sm font-bold text-white">₹{((Number(item?.price) || 0) * (Number(item?.cartQuantity) || 1)).toLocaleString('en-IN')}</p>
                  </div>
                ))
              )}
            </div>

            <div className="border-t border-white/10 pt-6 space-y-4">
              <div className="flex justify-between text-gray-400 text-sm">
                <span>Subtotal</span>
                <span>₹{cartTotal.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between text-gray-400 text-sm">
                <span>Shipping Estimate</span>
                <span>{shipping === 0 ? <span className="text-emerald-400 font-bold">FREE</span> : `₹${shipping}`}</span>
              </div>
              <div className="border-t border-white/10 pt-4 flex justify-between items-center">
                <span className="text-lg font-bold text-white">Grand Total</span>
                <span className="text-2xl font-black text-blue-400">₹{grandTotal.toLocaleString('en-IN')}</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default Checkout;