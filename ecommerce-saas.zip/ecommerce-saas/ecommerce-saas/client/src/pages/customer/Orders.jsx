import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiPackage, FiTruck, FiCheckCircle, FiClock, FiChevronDown, FiDownload } from 'react-icons/fi';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux'; // <-- NEW IMPORT

const OrderTimeline = ({ status }) => {
  const steps = [
    { name: "Order Placed", icon: FiClock },
    { name: "Processing", icon: FiPackage },
    { name: "Shipped", icon: FiTruck },
    { name: "Delivered", icon: FiCheckCircle }
  ];

  const getActiveIndex = () => {
    if (status === "Delivered") return 3;
    if (status === "Shipped") return 2;
    if (status === "Processing") return 1;
    return 0;
  };
  const activeIndex = getActiveIndex();

  return (
    <div className="relative flex justify-between items-center mt-8 mb-4 px-2 sm:px-8">
      <div className="absolute left-8 right-8 top-1/2 -translate-y-1/2 h-1 bg-gray-800 rounded-full z-0"></div>
      
      <motion.div 
        initial={{ width: 0 }}
        animate={{ width: `${(activeIndex / (steps.length - 1)) * 100}%` }}
        transition={{ duration: 1, ease: "easeOut" }}
        className="absolute left-8 top-1/2 -translate-y-1/2 h-1 bg-blue-500 rounded-full z-0 shadow-[0_0_10px_rgba(59,130,246,0.8)]"
        style={{ originX: 0 }}
      ></motion.div>

      {steps.map((step, index) => {
        const isActive = index <= activeIndex;
        const isCurrent = index === activeIndex;
        
        return (
          <div key={index} className="relative z-10 flex flex-col items-center">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center border-4 border-gray-900 transition-colors duration-500 ${
              isActive ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(59,130,246,0.5)]' : 'bg-gray-800 text-gray-500'
            }`}>
              <step.icon size={16} className={isCurrent ? 'animate-pulse' : ''} />
            </div>
            <span className={`text-[10px] sm:text-xs font-bold mt-3 uppercase tracking-wider ${isActive ? 'text-blue-400' : 'text-gray-600'}`}>
              {step.name}
            </span>
          </div>
        );
      })}
    </div>
  );
};

const Orders = () => {
  const [expandedOrder, setExpandedOrder] = useState(null);
  
  // --- GRAB LIVE ORDERS FROM REDUX ---
  const { orders } = useSelector((state) => state.orders);

  const toggleOrder = (id) => {
    if (expandedOrder === id) setExpandedOrder(null);
    else setExpandedOrder(id);
  };

  return (
    <div className="min-h-screen pt-32 px-6 pb-20 max-w-5xl mx-auto text-white relative z-10">
      
      <div className="mb-12 text-center md:text-left">
        <h1 className="text-4xl md:text-5xl font-black tracking-tight mb-4">My Orders</h1>
        <p className="text-gray-400 text-lg">Track, manage, and view your recent purchases.</p>
      </div>

      <div className="space-y-6">
        {orders.length === 0 ? (
          <div className="text-center py-20 bg-white/5 border border-white/10 rounded-3xl">
            <FiPackage size={48} className="mx-auto text-gray-600 mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">No orders yet!</h2>
            <p className="text-gray-400 mb-6">Looks like you haven't made a purchase yet.</p>
            <Link to="/shop" className="px-8 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl transition-colors inline-block">
              Start Shopping
            </Link>
          </div>
        ) : (
          orders.map((order) => (
            <div key={order.id} className="bg-gray-900/50 backdrop-blur-xl border border-white/10 rounded-3xl overflow-hidden shadow-2xl transition-all hover:border-white/20">
              
              <div 
                onClick={() => toggleOrder(order.id)}
                className="p-6 sm:p-8 cursor-pointer flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 hover:bg-white/[0.02] transition-colors"
              >
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <h3 className="text-xl font-bold text-white">{order.id}</h3>
                    <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                      order.status === 'Delivered' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/20' :
                      order.status === 'Shipped' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/20' :
                      'bg-purple-500/20 text-purple-400 border border-purple-500/20'
                    }`}>
                      {order.status}
                    </span>
                  </div>
                  <p className="text-gray-400 text-sm">Placed on {order.date}</p>
                </div>

                <div className="flex items-center justify-between w-full sm:w-auto gap-8">
                  <div className="text-left sm:text-right">
                    <p className="text-gray-400 text-xs uppercase tracking-wider mb-1">Total Amount</p>
                    <p className="text-xl font-black text-white">₹{order.total.toLocaleString('en-IN')}</p>
                  </div>
                  <motion.div animate={{ rotate: expandedOrder === order.id ? 180 : 0 }} className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400">
                    <FiChevronDown size={20} />
                  </motion.div>
                </div>
              </div>

              <AnimatePresence>
                {expandedOrder === order.id && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3, ease: "easeInOut" }}
                    className="border-t border-white/5"
                  >
                    <div className="p-6 sm:p-8 bg-black/20">
                      
                      <div className="mb-10">
                        <OrderTimeline status={order.status} />
                      </div>

                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div className="lg:col-span-2 space-y-4">
                          <h4 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4">Items in this order</h4>
                          {order.items.map((item, idx) => (
                            <div key={idx} className="flex items-center gap-4 p-4 bg-white/5 rounded-2xl border border-white/5">
                              <div className="w-16 h-16 rounded-xl bg-gray-900 overflow-hidden flex-shrink-0">
                                <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
                              </div>
                              <div className="flex-1">
                                {/* Using item.title because that's what is in cartItems */}
                                <h5 className="font-medium text-white">{item.title}</h5>
                                <p className="text-sm text-gray-400">Qty: {item.cartQuantity}</p>
                              </div>
                              <div className="text-right">
                                <p className="font-bold text-white">₹{item.price.toLocaleString('en-IN')}</p>
                              </div>
                            </div>
                          ))}
                        </div>

                        <div className="space-y-4">
                          <h4 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4">Order Actions</h4>
                          <button className="w-full py-3 bg-white/5 hover:bg-white/10 border border-white/10 text-white font-medium rounded-xl transition-colors flex items-center justify-center gap-2">
                            <FiDownload /> Download Invoice
                          </button>
                          <Link to="/shop" className="w-full py-3 bg-blue-600/20 hover:bg-blue-600 text-blue-400 hover:text-white font-medium rounded-xl transition-colors flex items-center justify-center gap-2 border border-blue-500/20">
                            Buy Again
                          </Link>
                          
                          <div className="mt-6 p-5 bg-white/[0.02] rounded-2xl border border-white/5 text-sm">
                            <p className="text-gray-400 mb-1">Shipping Address</p>
                            <p className="text-white font-medium">Customer Name</p>
                            <p className="text-gray-300">Payment Processed Securely</p>
                          </div>
                        </div>

                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

            </div>
          ))
        )}
      </div>

    </div>
  );
};

export default Orders;