import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import API from '../../services/axios'
import { addToCart } from '../../features/cart/cartSlice'

const ProductPage = () => {
  const { id } = useParams()
  const dispatch = useDispatch()
  const [product, setProduct] = useState(null)

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const { data } = await API.get(`/products/${id}`)
        setProduct(data)
      } catch (error) {
        console.error("Failed to fetch product:", error)
      }
    }

    fetchProduct()
  }, [id]) // CRITICAL FIX: 'id' must be in the dependency array

  const addCartHandler = () => {
    if (product) dispatch(addToCart(product))
  }

  if (!product) return <h1>Loading...</h1>

  return (
    <div>
      <h1>{product.title}</h1>
      <p>{product.description}</p>
      <p>₹ {product.price}</p>
      <button onClick={addCartHandler}>Add To Cart</button>
    </div>
  )
}

export default ProductPage