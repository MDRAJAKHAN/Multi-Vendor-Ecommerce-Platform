import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiSearch, FiArrowRight, FiShoppingCart, FiFilter, FiX } from 'react-icons/fi';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { addToCart, toggleCartDrawer } from '../../features/cart/cartSlice';

const categories = ["All", "Electronics", "Clothing", "Home", "Books", "Gaming", "Fitness"];

// SKELETON LOADER COMPONENT
const SkeletonCard = () => (
  <div className="bg-white/[0.02] border border-white/5 rounded-2xl p-4 flex flex-col h-full animate-pulse">
    <div className="h-56 w-full bg-gray-800 rounded-xl mb-4"></div>
    <div className="h-6 w-3/4 bg-gray-800 rounded-md mb-2"></div>
    <div className="h-4 w-1/2 bg-gray-800 rounded-md mt-auto mb-4"></div>
    <div className="flex justify-between items-center border-t border-white/5 pt-4">
      <div className="h-6 w-1/3 bg-gray-800 rounded-md"></div>
      <div className="flex gap-2">
        <div className="h-10 w-10 bg-gray-800 rounded-xl"></div>
        <div className="h-10 w-10 bg-gray-800 rounded-xl"></div>
      </div>
    </div>
  </div>
);

const Shop = () => {
  const { products } = useSelector((state) => state.products);

  const [filteredProducts, setFilteredProducts] = useState([]);
  const [activeCategory, setActiveCategory] = useState("All");
  
  const [searchQuery, setSearchQuery] = useState(""); 
  const [debouncedQuery, setDebouncedQuery] = useState(""); 
  
  const [sortOrder, setSortOrder] = useState("none");
  const [quickViewProduct, setQuickViewProduct] = useState(null);
  
  // Make sure this is defined!
  const [isLoading, setIsLoading] = useState(true);
  
  const dispatch = useDispatch();

  // 1. DEBOUNCE EFFECT
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 300);

    return () => {
      clearTimeout(handler);
    };
  }, [searchQuery]); 

  // 2. DATA FETCHING EFFECT (Memory-Leak Proof)
  useEffect(() => {
    let isMounted = true; 
    
    // It is safe to set loading to true immediately
    setIsLoading(true);
    
    const timer = setTimeout(() => {
      // ENTERPRISE FIX: Stop everything if the user navigated away from the page!
      if (!isMounted) return; 

      try {
        let result = Array.isArray(products) ? [...products] : [];

        if (activeCategory && activeCategory !== "All") {
          result = result.filter(p => p && p.category === activeCategory);
        }
        
        if (debouncedQuery) {
          const lowerQuery = debouncedQuery.toLowerCase();
          result = result.filter(p => {
            if (!p || !p.title) return false;
            return String(p.title).toLowerCase().includes(lowerQuery);
          });
        }
        
        if (sortOrder === "asc") {
          result.sort((a, b) => (Number(a?.price) || 0) - (Number(b?.price) || 0));
        } else if (sortOrder === "desc") {
          result.sort((a, b) => (Number(b?.price) || 0) - (Number(a?.price) || 0));
        }

        // ENTERPRISE FIX: Only update state if the component is still alive
        if (isMounted) {
          setFilteredProducts(result);
          setIsLoading(false);
        }
        
      } catch (error) {
        console.error("Error during filtering:", error);
        if (isMounted) {
          setFilteredProducts([]);
          setIsLoading(false);
        }
      }
    }, 600); 

    return () => {
      // Cleanup function runs when component unmounts
      isMounted = false; 
      clearTimeout(timer);
    };
  }, [activeCategory, debouncedQuery, sortOrder, products]);

  const handleAddToCart = (product) => {
    dispatch(addToCart(product));
    dispatch(toggleCartDrawer(true)); 
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.4 } }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="min-h-screen bg-transparent text-white pt-32 px-6 pb-20 relative">
      
      {/* Sticky Header */}
      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row justify-between items-center gap-6 mb-12 pb-6 border-b border-white/5 sticky top-24 z-40 bg-gray-950/90 backdrop-blur-xl p-4 rounded-3xl shadow-2xl">
        <div className="flex flex-wrap gap-2 justify-center lg:justify-start">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                activeCategory === cat ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' : 'bg-white/5 text-gray-400 hover:text-white hover:bg-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="flex w-full lg:w-auto gap-3">
          <div className="relative hidden md:flex items-center bg-white/5 border border-white/5 rounded-xl px-3">
            <FiFilter className="text-gray-500 mr-2" />
            <select 
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value)}
              className="bg-transparent text-sm text-gray-300 focus:outline-none appearance-none cursor-pointer py-2.5 pr-4"
            >
              <option value="none" className="bg-gray-900">Sort by: Default</option>
              <option value="asc" className="bg-gray-900">Price: Low to High</option>
              <option value="desc" className="bg-gray-900">Price: High to Low</option>
            </select>
          </div>

          <div className="relative flex-grow md:w-64">
            <FiSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
            <input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-11 pr-4 py-2.5 bg-white/5 border border-white/5 rounded-xl text-sm text-white focus:outline-none focus:border-blue-500/50 transition-colors"
            />
          </div>
        </div>
      </div>

      {/* Product Grid */}
      <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-10">
        <AnimatePresence mode="wait">
          {isLoading ? (
            Array.from({ length: 8 }).map((_, idx) => (
              <motion.div key={`skeleton-${idx}`} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <SkeletonCard />
              </motion.div>
            ))
          ) : filteredProducts.length === 0 ? (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="col-span-full text-center py-20 text-gray-500">
              No products found matching your criteria.
            </motion.div>
          ) : (
            filteredProducts.map((product, index) => (
              <motion.div
                key={product?._id || `product-${index}`}
                layout 
                variants={cardVariants}
                initial="hidden"
                animate="visible"
                whileHover={{ y: -12, scale: 1.02, boxShadow: "0px 20px 40px rgba(59, 130, 246, 0.2)" }}
                className="bg-white/[0.03] border border-white/5 rounded-2xl p-4 flex flex-col h-full hover:border-blue-500/30 transition-colors group relative backdrop-blur-sm"
              >
                <button 
                  onClick={() => setQuickViewProduct(product)}
                  className="h-56 w-full rounded-xl mb-4 overflow-hidden relative z-10 border border-white/5 bg-gray-900 cursor-zoom-in"
                >
                  <img 
                    src={product?.image} 
                    alt={product?.title || "Product"} 
                    loading="lazy"
                    onError={(e) => { e.target.src = "https://images.unsplash.com/photo-1560393464-5c69a73c5770?w=600&q=80" }}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
                  />
                  <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-lg text-[10px] uppercase font-bold text-white tracking-wider border border-white/10">
                    {product?.category || "Misc"}
                  </div>
                </button>
                
                <h3 className="font-semibold text-white mb-2 line-clamp-2 z-10 text-lg leading-tight">
                  {product?.title || "Unnamed Product"}
                </h3>
                
                <div className="flex justify-between items-center mt-auto pt-4 border-t border-white/5 z-10">
                  <span className="text-xl font-black bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                    ₹{Number(product?.price || 0).toLocaleString('en-IN')}
                  </span>
                  
                  <div className="flex items-center space-x-3">
                    <button onClick={() => handleAddToCart(product)} className="p-3 bg-blue-600/20 text-blue-400 hover:bg-blue-600 hover:text-white rounded-xl transition-all hover:scale-110 active:scale-95">
                      <FiShoppingCart size={18} />
                    </button>
                    <Link to={`/product/${product?._id}`} className="flex items-center justify-center p-3 bg-white/5 hover:bg-white/10 rounded-xl transition-colors">
                      <FiArrowRight size={18} className="text-gray-400 hover:text-white" />
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>

      {/* QUICK VIEW MODAL */}
      <AnimatePresence>
        {quickViewProduct && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setQuickViewProduct(null)}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 bg-black/70 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              onClick={(e) => e.stopPropagation()} 
              className="bg-gray-900 border border-white/10 rounded-3xl w-full max-w-4xl shadow-2xl overflow-hidden relative flex flex-col md:flex-row"
            >
              <button onClick={() => setQuickViewProduct(null)} className="absolute top-4 right-4 z-50 p-2 bg-black/50 hover:bg-red-500/80 text-white rounded-full backdrop-blur-md transition-colors">
                <FiX size={20} />
              </button>
              <div className="w-full md:w-1/2 h-64 md:h-auto bg-black relative">
                <img src={quickViewProduct?.image} alt={quickViewProduct?.title} className="w-full h-full object-cover" />
              </div>
              <div className="w-full md:w-1/2 p-8 md:p-10 flex flex-col justify-center bg-gray-900/80 backdrop-blur-xl">
                <span className="text-blue-500 text-xs font-bold uppercase tracking-widest mb-2">{quickViewProduct?.category}</span>
                <h2 className="text-3xl font-black text-white mb-4 leading-tight">{quickViewProduct?.title}</h2>
                <p className="text-2xl text-gray-300 font-light mb-6">₹{Number(quickViewProduct?.price || 0).toLocaleString('en-IN')}</p>
                <p className="text-gray-400 text-sm leading-relaxed mb-8">Get a closer look at this premium {quickViewProduct?.category?.toLowerCase() || 'item'}. Built for performance and designed to elevate your lifestyle. Fully in-stock and ready to ship.</p>
                <div className="flex gap-4 mt-auto">
                  <button 
                    onClick={() => { handleAddToCart(quickViewProduct); setQuickViewProduct(null); }}
                    className="flex-1 flex items-center justify-center space-x-2 bg-blue-600 hover:bg-blue-500 text-white py-4 rounded-xl font-bold transition-all hover:scale-105 active:scale-95 shadow-lg shadow-blue-500/30"
                  >
                    <FiShoppingCart size={18} /><span>Add to Cart</span>
                  </button>
                  <Link to={`/product/${quickViewProduct?._id}`} className="px-6 flex items-center justify-center bg-white/5 hover:bg-white/10 text-white py-4 rounded-xl font-bold transition-colors border border-white/5">
                    Details
                  </Link>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default Shop;