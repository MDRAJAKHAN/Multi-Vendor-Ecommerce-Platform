import { useParams, Link } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { addToCart } from '../../features/cart/cartSlice';
import { mockProducts } from '../../data/mockProducts';
import { FiArrowLeft, FiShoppingCart } from 'react-icons/fi';

const ProductDetails = () => {
  const { id } = useParams(); // Grabs the ID from the URL
  const dispatch = useDispatch();

  // Find the exact product from our database
  const product = mockProducts.find((p) => p._id === id);

  if (!product) {
    return (
      <div className="min-h-screen pt-32 text-center text-white">
        <h2 className="text-3xl font-bold">Product not found!</h2>
        <Link to="/shop" className="text-blue-500 mt-4 inline-block">Go back to shop</Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-32 px-6 max-w-5xl mx-auto text-white">
      <Link to="/shop" className="inline-flex items-center text-gray-400 hover:text-white mb-8 transition-colors">
        <FiArrowLeft className="mr-2" /> Back to Shop
      </Link>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="rounded-3xl overflow-hidden border border-white/10 bg-gray-900">
          <img src={product.image} alt={product.title} className="w-full h-full object-cover" />
        </div>
        <div className="flex flex-col justify-center">
          <span className="text-blue-500 text-sm font-bold uppercase tracking-widest mb-2">{product.category}</span>
          <h1 className="text-4xl font-black mb-4">{product.title}</h1>
          <p className="text-3xl text-gray-300 font-light mb-8">₹{product.price.toLocaleString('en-IN')}</p>
          
          <p className="text-gray-400 leading-relaxed mb-8">
            This is a premium high-quality product. Build scalable modern e-commerce platforms with this amazing {product.title.toLowerCase()}.
          </p>

          <button 
            onClick={() => dispatch(addToCart(product))}
            className="flex items-center justify-center space-x-3 bg-blue-600 hover:bg-blue-500 text-white py-4 px-8 rounded-xl font-bold transition-all hover:scale-105 active:scale-95"
          >
            <FiShoppingCart size={20} />
            <span>Add to Cart</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;