import { useSelector, useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import { FiTrash2, FiMinus, FiPlus, FiArrowLeft } from 'react-icons/fi';
import { removeFromCart, decreaseCart, addToCart, clearCart } from '../../features/cart/cartSlice';

const Cart = () => {
  // 1. Grab the cart data from Redux!
  const cart = useSelector((state) => state.cart);
  const dispatch = useDispatch();

  // 2. Calculate the total price dynamically
  const cartTotal = cart.cartItems.reduce((total, item) => total + item.price * item.cartQuantity, 0);

  return (
    <div className="min-h-screen pt-24 pb-12 px-6 max-w-7xl mx-auto">
      <h2 className="text-3xl font-bold text-white mb-8">Your Shopping Cart</h2>

      {cart.cartItems.length === 0 ? (
        // --- EMPTY CART STATE ---
        <div className="text-center py-20 bg-white/[0.02] border border-white/5 rounded-3xl backdrop-blur-sm">
          <h3 className="text-xl text-gray-400 mb-6">Your cart is currently empty</h3>
          <Link to="/shop" className="inline-flex items-center text-blue-500 hover:text-blue-400 font-medium">
            <FiArrowLeft className="mr-2" /> Start Shopping
          </Link>
        </div>
      ) : (
        // --- CART WITH ITEMS ---
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Side: Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cart.cartItems.map((item) => (
              <div key={item._id} className="flex items-center justify-between p-4 bg-white/[0.02] border border-white/5 rounded-2xl">
                <div className="flex items-center space-x-4">
                  {/* You can add an <img src={item.image} /> here later! */}
                  <div className="w-16 h-16 bg-gray-800 rounded-xl flex items-center justify-center text-xs text-gray-500">Image</div>
                  <div>
                    <h3 className="text-white font-medium">{item.name || item.title}</h3>
                    <p className="text-gray-400 text-sm">₹{item.price}</p>
                  </div>
                </div>

                {/* Quantity Controls */}
                <div className="flex items-center space-x-4">
                  <div className="flex items-center border border-white/10 rounded-lg">
                    <button onClick={() => dispatch(decreaseCart(item))} className="p-2 text-gray-400 hover:text-white transition-colors">
                      <FiMinus size={14} />
                    </button>
                    <span className="w-8 text-center text-white text-sm">{item.cartQuantity}</span>
                    <button onClick={() => dispatch(addToCart(item))} className="p-2 text-gray-400 hover:text-white transition-colors">
                      <FiPlus size={14} />
                    </button>
                  </div>
                  
                  {/* Remove Button */}
                  <button onClick={() => dispatch(removeFromCart(item))} className="p-2 text-red-500 hover:bg-red-500/10 rounded-lg transition-colors">
                    <FiTrash2 size={18} />
                  </button>
                </div>
              </div>
            ))}
            
            <button onClick={() => dispatch(clearCart())} className="text-sm text-red-500 hover:text-red-400 mt-4 px-2">
              Clear Entire Cart
            </button>
          </div>

          {/* Right Side: Order Summary */}
          <div className="bg-white/[0.02] border border-white/5 rounded-3xl p-6 h-fit sticky top-28">
            <h3 className="text-xl font-bold text-white mb-6">Order Summary</h3>
            <div className="space-y-4 text-sm mb-6">
              <div className="flex justify-between text-gray-400">
                <span>Subtotal</span>
                <span className="text-white">₹{cartTotal}</span>
              </div>
              <div className="flex justify-between text-gray-400">
                <span>Taxes & Shipping</span>
                <span className="text-gray-500">Calculated at checkout</span>
              </div>
              <div className="border-t border-white/10 pt-4 flex justify-between font-bold text-lg">
                <span className="text-white">Total</span>
                <span className="text-blue-500">₹{cartTotal}</span>
              </div>
            </div>
            <button className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl transition-colors shadow-lg">
              Proceed to Checkout
            </button>
          </div>

        </div>
      )}
    </div>
  );
};

export default Cart;