import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { FiArrowLeft, FiMail, FiLock, FiCheckCircle } from 'react-icons/fi';
import { useDispatch } from 'react-redux';
import toast from 'react-hot-toast';

import { sendOtp, resetPasswordWithOtp } from '../../features/auth/authThunk';

const ForgotPassword = () => {
  // Step Management: 1 = Email, 2 = OTP & New Password, 3 = Success
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  
  // Form Data
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');

  const dispatch = useDispatch();
  const navigate = useNavigate();

  // --- HANDLERS ---
  const handleRequestOtp = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    const resultAction = await dispatch(sendOtp(email));
    if (sendOtp.fulfilled.match(resultAction)) {
      toast.success("OTP sent to your email!");
      setStep(2); // Move to OTP step
    } else {
      toast.error("Failed to send OTP.");
    }
    setLoading(false);
  };

  const handleResetPassword = async (e) => {
    e.preventDefault();
    setLoading(true);

    const resultAction = await dispatch(resetPasswordWithOtp({ email, otp, newPassword }));
    if (resetPasswordWithOtp.fulfilled.match(resultAction)) {
      setStep(3); // Move to Success step
    } else {
      toast.error(resultAction.payload || "Invalid OTP Code. Try '123456'");
    }
    setLoading(false);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="min-h-screen flex items-center justify-center pt-20 px-6">
      <div className="w-full max-w-md bg-white/[0.02] border border-white/10 rounded-3xl p-8 backdrop-blur-sm shadow-2xl relative overflow-hidden">
        
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-32 bg-blue-500/10 blur-[50px] pointer-events-none" />

        {step !== 3 && (
          <Link to="/login" className="inline-flex items-center text-sm text-gray-400 hover:text-white transition-colors mb-6 group relative z-10">
            <FiArrowLeft className="mr-2 transform group-hover:-translate-x-1 transition-transform" /> Back to login
          </Link>
        )}

        <AnimatePresence mode="wait">
          
          {/* STEP 1: ENTER EMAIL */}
          {step === 1 && (
            <motion.div key="step1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <div className="mb-8">
                <h2 className="text-3xl font-bold text-white mb-2">Reset Password</h2>
                <p className="text-gray-400 text-sm">Enter your email and we'll send you a 6-digit verification code.</p>
              </div>

              <form onSubmit={handleRequestOtp} className="space-y-5">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">Email Address</label>
                  <div className="relative">
                    <FiMail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
                    <input 
                      type="email" value={email} onChange={(e) => setEmail(e.target.value)} required 
                      className="w-full pl-11 pr-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white focus:outline-none focus:border-blue-500" 
                      placeholder="name@example.com" 
                    />
                  </div>
                </div>

                <button disabled={loading} type="submit" className="w-full py-3 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-800 text-white font-bold rounded-xl transition-colors shadow-lg">
                  {loading ? "Sending Code..." : "Send OTP"}
                </button>
              </form>
            </motion.div>
          )}

          {/* STEP 2: ENTER OTP & NEW PASSWORD */}
          {step === 2 && (
            <motion.div key="step2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <div className="mb-8">
                <h2 className="text-3xl font-bold text-white mb-2">Secure Verification</h2>
                <p className="text-gray-400 text-sm">We sent a code to <span className="text-white">{email}</span></p>
              </div>

              <form onSubmit={handleResetPassword} className="space-y-5">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">6-Digit OTP</label>
                  <input 
                    type="text" maxLength="6" value={otp} onChange={(e) => setOtp(e.target.value.replace(/[^0-9]/g, ''))} required 
                    className="w-full px-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white focus:outline-none focus:border-blue-500 text-center text-2xl tracking-[0.5em] font-mono" 
                    placeholder="------" 
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">New Password</label>
                  <div className="relative">
                    <FiLock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
                    <input 
                      type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required minLength="6"
                      className="w-full pl-11 pr-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white focus:outline-none focus:border-blue-500" 
                      placeholder="Enter new password" 
                    />
                  </div>
                </div>

                <button disabled={loading} type="submit" className="w-full py-3 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-800 text-white font-bold rounded-xl transition-colors shadow-lg mt-4">
                  {loading ? "Verifying..." : "Reset Password"}
                </button>
                <button type="button" onClick={() => setStep(1)} className="w-full py-3 text-sm text-gray-400 hover:text-white transition-colors">
                  Wrong email? Go back
                </button>
              </form>
            </motion.div>
          )}

          {/* STEP 3: SUCCESS */}
          {step === 3 && (
            <motion.div key="step3" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center py-6">
              <div className="w-16 h-16 bg-emerald-500/10 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <FiCheckCircle size={32} />
              </div>
              <h2 className="text-2xl font-bold text-white mb-3">Password Updated!</h2>
              <p className="text-gray-400 text-sm mb-8">Your password has been successfully reset. You can now log in with your new credentials.</p>
              <button onClick={() => navigate('/login')} className="w-full py-3 bg-white text-gray-950 font-bold rounded-xl hover:bg-gray-200 transition-colors">
                Go to Login
              </button>
            </motion.div>
          )}

        </AnimatePresence>
      </div>
    </motion.div>
  );
};

export default ForgotPassword;