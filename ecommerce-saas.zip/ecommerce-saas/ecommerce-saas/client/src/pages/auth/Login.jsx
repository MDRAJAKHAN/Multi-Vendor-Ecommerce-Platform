import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useDispatch } from 'react-redux';
import toast from 'react-hot-toast';

// --- NEW PRO IMPORTS ---
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';

import { loginUser } from '../../features/auth/authThunk';
import { loginSuccess } from '../../features/auth/authSlice';

// 1. DEFINE THE STRICT RULES (ZOD SCHEMA)
const loginSchema = z.object({
  email: z.string().min(1, { message: "Email is required" }).email({ message: "Please enter a valid email format" }),
  password: z.string().min(6, { message: "Password must be at least 6 characters long" })
});

const Login = () => {
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  // 2. CONNECT REACT HOOK FORM
  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(loginSchema)
  });

  // 3. HANDLE SUBMIT (This ONLY runs if the rules above are passed!)
  const onSubmit = async (data) => {
    setLoading(true);
    
    // Notice we pass 'data' directly, no more manual state variables!
    const resultAction = await dispatch(loginUser(data));
    
    if (loginUser.fulfilled.match(resultAction)) {
      dispatch(loginSuccess(resultAction.payload));
      toast.success(`Welcome back!`);
      
      if (resultAction.payload.user.role === 'admin') {
        navigate('/admin');
      } else {
        navigate('/orders');
      }
    } else {
      toast.error(resultAction.payload || "Invalid credentials.");
    }
    setLoading(false);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="min-h-screen flex items-center justify-center pt-20 px-6">
      <div className="w-full max-w-md bg-white/[0.02] border border-white/10 rounded-3xl p-8 backdrop-blur-sm shadow-2xl">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Secure Login</h2>
          <p className="text-gray-400 text-sm">Enter your credentials to access your account.</p>
        </div>

        {/* Note the handleSubmit wrapper! */}
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
          
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">Email</label>
            <input 
              type="email" 
              {...register("email")} // This wires the input to Zod
              className={`w-full px-4 py-3 bg-gray-900/50 border rounded-xl text-white focus:outline-none transition-colors ${
                errors.email ? 'border-red-500 focus:border-red-500' : 'border-white/10 focus:border-blue-500'
              }`}
            />
            {/* Display the dynamic error message */}
            {errors.email && <p className="text-red-500 text-xs mt-1.5 font-medium">{errors.email.message}</p>}
          </div>
          
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="block text-sm font-medium text-gray-400">Password</label>
              <Link to="/forgot-password" className="text-xs text-blue-500 hover:text-blue-400">Forgot password?</Link>
            </div>
            <input 
              type="password" 
              {...register("password")} // This wires the input to Zod
              className={`w-full px-4 py-3 bg-gray-900/50 border rounded-xl text-white focus:outline-none transition-colors ${
                errors.password ? 'border-red-500 focus:border-red-500' : 'border-white/10 focus:border-blue-500'
              }`}
            />
            {/* Display the dynamic error message */}
            {errors.password && <p className="text-red-500 text-xs mt-1.5 font-medium">{errors.password.message}</p>}
          </div>

          <button disabled={loading} type="submit" className="w-full py-3 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-800 text-white font-bold rounded-xl transition-colors shadow-lg mt-4">
            {loading ? "Authenticating..." : "Sign In"}
          </button>
        </form>

        <p className="text-center text-sm text-gray-500 mt-6">
          Don't have an account? <Link to="/register" className="text-blue-500 hover:text-blue-400 font-medium">Sign up</Link>
        </p>
      </div>
    </motion.div>
  );
};

export default Login;