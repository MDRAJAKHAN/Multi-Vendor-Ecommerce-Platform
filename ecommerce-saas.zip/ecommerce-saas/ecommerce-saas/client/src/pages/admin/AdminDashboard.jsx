import { Link } from 'react-router-dom'

const AdminDashboard = () => {
  return (
    <div>
      <h1>Admin Dashboard</h1>

      <Link to='/admin/manage-products'>
        Manage Products
      </Link>

      <br />

      <Link to='/admin/manage-users'>
        Manage Users
      </Link>

      <br />

      <Link to='/admin/reports'>
        Reports
      </Link>
    </div>
  )
}

export default AdminDashboard