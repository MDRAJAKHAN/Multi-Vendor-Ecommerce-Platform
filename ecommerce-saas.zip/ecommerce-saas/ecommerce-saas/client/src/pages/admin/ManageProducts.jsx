import { useEffect, useState } from 'react';
import API from '../../services/axios';

const ManageProducts = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const { data } = await API.get('/products');
      setProducts(data);
    } catch (error) {
      console.log(error);
    }
  };

  const deleteHandler = async (id) => {
    try {
      await API.delete(`/products/${id}`);
      fetchProducts();
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div>
      <h1>Manage Products</h1>
      {products.map((product) => (
        <div key={product._id}>
          <h2>{product.title}</h2>
          <button onClick={() => deleteHandler(product._id)}>Delete</button>
        </div>
      ))}
    </div>
  );
};

export default ManageProducts;