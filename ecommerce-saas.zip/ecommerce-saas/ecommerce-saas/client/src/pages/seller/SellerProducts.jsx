import { useEffect, useState } from 'react'

import API from '../../services/axios'

const SellerProducts = () => {
  const [products, setProducts] = useState([])

  useEffect(() => {
    fetchProducts()
  }, [])

  const fetchProducts = async () => {
    try {
      const { data } = await API.get(
        '/products'
      )

      setProducts(data)
    } catch (error) {
      console.log(error)
    }
  }

  return (
    <div>
      <h1>Seller Products</h1>

      {products.map((product) => (
        <div key={product._id}>
          <h3>{product.title}</h3>

          <p>₹ {product.price}</p>
        </div>
      ))}
    </div>
  )
}

export default SellerProducts