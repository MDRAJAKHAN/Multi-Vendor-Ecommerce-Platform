import { useState } from 'react'
import API from '../../services/axios'

const AddProduct = () => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: '',
    stock: '',
    image: '',
  })

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    try {
      await API.post('/products', formData)

      alert('Product Added')
    } catch (error) {
      console.log(error)
    }
  }

  return (
    <div>
      <h1>Add Product</h1>

      <form onSubmit={handleSubmit}>
        <input
          type='text'
          name='title'
          placeholder='Title'
          onChange={handleChange}
        />

        <input
          type='text'
          name='description'
          placeholder='Description'
          onChange={handleChange}
        />

        <input
          type='number'
          name='price'
          placeholder='Price'
          onChange={handleChange}
        />

        <input
          type='number'
          name='stock'
          placeholder='Stock'
          onChange={handleChange}
        />

        <input
          type='text'
          name='image'
          placeholder='Image URL'
          onChange={handleChange}
        />

        <button type='submit'>
          Add Product
        </button>
      </form>
    </div>
  )
}

export default AddProduct