import { useEffect, useState } from 'react'
import API from '../../services/axios'

const SellerOrders = () => {
  const [orders, setOrders] = useState([])

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const { data } = await API.get('/orders')
        setOrders(Array.isArray(data) ? data : (data.orders || []))
      } catch (error) {
        console.error("Failed to fetch seller orders:", error)
      }
    }

    fetchOrders()
  }, [])

  return (
    <div className='p-10'>
      <h1 className='text-3xl font-bold mb-5'>Seller Orders</h1>

      {orders.length === 0 ? (
        <h2>No Orders</h2>
      ) : (
        orders.map((order) => (
          <div key={order._id} className='border p-5 mb-4 rounded-lg'>
            <p>Total: ₹ {order.totalPrice}</p>
            <p>Status: {order.orderStatus}</p>
          </div>
        ))
      )}
    </div>
  )
}

export default SellerOrders