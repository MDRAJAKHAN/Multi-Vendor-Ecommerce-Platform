import { Link } from 'react-router-dom'

const ProductCard = ({ product }) => {
  return (
    <div className='border p-5 rounded-xl shadow-lg'>
      <img
        src='https://via.placeholder.com/250'
        alt='product'
        className='w-full rounded-lg'
      />

      <h2 className='text-2xl font-bold mt-3'>
        {product.title}
      </h2>

      <p className='text-gray-600 mt-2'>
        {product.description}
      </p>

      <p className='text-xl font-bold mt-2'>
        ₹ {product.price}
      </p>

      <Link to={`/product/${product._id}`}>
        <button className='bg-black text-white px-5 py-2 rounded-lg mt-4'>
          View Product
        </button>
      </Link>
    </div>
  )
}

export default ProductCard