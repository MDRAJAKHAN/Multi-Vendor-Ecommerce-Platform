const SellerSidebar = () => {
  return (
    <div>
      <h2>Seller Sidebar</h2>
    </div>
  )
}

export default SellerSidebar