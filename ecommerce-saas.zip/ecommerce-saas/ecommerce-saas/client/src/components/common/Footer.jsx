const Footer = () => {
  return (
    <footer className='bg-black text-white text-center py-5'>
      <h2>
        © 2026 Multi Vendor E-Commerce SaaS
      </h2>
    </footer>
  )
}

export default Footer