import { motion } from 'framer-motion';

const PageWrapper = ({ children }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}    // Starts slightly transparent and pushed down
      animate={{ opacity: 1, y: 0 }}     // Slides up smoothly into place
      exit={{ opacity: 0, y: -15 }}      // Slides up and fades out when leaving
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="w-full"
    >
      {children}
    </motion.div>
  );
};

export default PageWrapper;