import { Link, useLocation } from 'react-router-dom';
import { FiShoppingCart, FiUser, FiChevronDown, FiLogOut, FiPackage, FiActivity } from 'react-icons/fi';
import { useSelector, useDispatch } from 'react-redux';
import { toggleCartDrawer } from '../../features/cart/cartSlice';
import { logout } from '../../features/auth/authSlice'; // <-- 1. Import logout action

const Navbar = () => {
  const location = useLocation();
  const dispatch = useDispatch();
  const isActive = (path) => location.pathname === path;

  const cartItems = useSelector((state) => state.cart?.cartItems || []);
  
  // <-- 2. Grab Auth State -->
  const { isAuthenticated, user, role } = useSelector((state) => state.auth);

  return (
    <nav className="fixed w-full top-0 z-50 bg-gray-950/70 backdrop-blur-md border-b border-white/5 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-6 h-20 flex justify-between items-center">
        
        {/* Logo */}
        <Link to="/" className="text-xl font-black tracking-tight text-white hover:opacity-90 transition-opacity">
          E-Commerce <span className="text-blue-500">SaaS</span>
        </Link>

        {/* Center Nav Links */}
        <div className="hidden md:flex items-center space-x-10 text-sm font-medium">
          {[
            { name: 'Home', path: '/' },
            { name: 'Shop', path: '/shop' }
          ].map((link) => (
            <Link
              key={link.name}
              to={link.path}
              className={`relative py-2 transition-colors duration-300 ${
                isActive(link.path) ? 'text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              {link.name}
              {isActive(link.path) && (
                <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-blue-500 rounded-full" />
              )}
            </Link>
          ))}
        </div>

        {/* Right Controls */}
        <div className="flex items-center space-x-6 text-gray-400">
          
          {/* CART DRAWER BUTTON */}
          <button 
            onClick={() => dispatch(toggleCartDrawer(true))}
            className="hover:text-white transition-colors relative p-1 cursor-pointer"
          >
            <FiShoppingCart size={20} />
            {cartItems.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-blue-500 rounded-full text-[10px] text-white font-bold flex items-center justify-center">
                {cartItems.length}
              </span>
            )}
          </button>

          {/* <-- 3. DYNAMIC LOGIN / PROFILE MENU --> */}
          {isAuthenticated ? (
            <div className="relative group cursor-pointer">
              {/* Profile Badge */}
              <div className="flex items-center space-x-2 bg-blue-500/10 border border-blue-500/20 text-blue-400 px-4 py-2 rounded-xl text-sm font-bold transition-all hover:bg-blue-500/20">
                <FiUser size={16} />
                <span>{user?.name ? user.name.split(' ')[0] : 'Profile'}</span>
                <FiChevronDown size={14} className="group-hover:rotate-180 transition-transform" />
              </div>

              {/* Invisible Hover Bridge (prevents menu from closing when moving mouse down) */}
              <div className="absolute top-full right-0 w-full h-4"></div>

              {/* Dropdown Menu */}
              <div className="absolute top-[calc(100%+0.5rem)] right-0 w-48 bg-gray-900/95 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 overflow-hidden flex flex-col">
                <div className="px-4 py-3 border-b border-white/5">
                  <p className="text-xs text-gray-400 uppercase tracking-wider">Signed in as</p>
                  <p className="text-sm text-white font-bold truncate">{user?.email || 'user@example.com'}</p>
                </div>
                
                <Link to="/orders" className="px-4 py-3 text-sm text-gray-300 hover:text-white hover:bg-white/5 flex items-center gap-3 transition-colors">
                  <FiPackage /> My Orders
                </Link>
                
                {/* Only show Dashboard if they are a vendor */}
                {role === 'vendor' && (
                  <Link to="/dashboard" className="px-4 py-3 text-sm text-gray-300 hover:text-white hover:bg-white/5 flex items-center gap-3 transition-colors">
                    <FiActivity /> Dashboard
                  </Link>
                )}
                
                <button 
                  onClick={() => dispatch(logout())}
                  className="px-4 py-3 text-sm text-red-400 hover:text-red-300 hover:bg-red-500/10 flex items-center gap-3 transition-colors text-left"
                >
                  <FiLogOut /> Logout
                </button>
              </div>
            </div>
          ) : (
            <Link to="/login" className="flex items-center space-x-2 bg-white/5 border border-white/10 hover:border-white/20 text-white px-4 py-2 rounded-xl text-sm font-medium transition-all">
              <FiUser size={16} />
              <span>Login</span>
            </Link>
          )}
          
        </div>
      </div>
    </nav>
  );
};

export default Navbar; 