import { motion, AnimatePresence } from 'framer-motion';
import { FiX, FiTrash2, FiMinus, FiPlus, FiShoppingBag } from 'react-icons/fi';
import { useSelector, useDispatch } from 'react-redux';
import { toggleCartDrawer, removeFromCart, decreaseCart, addToCart } from '../../features/cart/cartSlice';
import { useNavigate } from 'react-router-dom';

const CartDrawer = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { cartItems, isCartOpen } = useSelector((state) => state.cart);
  
  // Calculate total price
  const cartTotal = cartItems.reduce((total, item) => total + item.price * item.cartQuantity, 0);

  const handleProceedToCheckout = () => {
    // First, close the drawer
    dispatch(toggleCartDrawer(false));
    // Then, navigate to the checkout page
    navigate('/checkout');
  };

  return (
    <AnimatePresence>
      {isCartOpen && (
        <>
          {/* 1. Dark Overlay Background */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => dispatch(toggleCartDrawer(false))}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
          />

          {/* 2. The Sliding Drawer */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed top-0 right-0 h-full w-full sm:w-[450px] bg-gray-950 border-l border-white/10 z-50 flex flex-col shadow-2xl"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-white/10">
              <h2 className="text-xl font-bold text-white flex items-center">
                <FiShoppingBag className="mr-3 text-blue-500" /> Your Cart
              </h2>
              <button 
                onClick={() => dispatch(toggleCartDrawer(false))}
                className="p-2 text-gray-400 hover:text-white hover:bg-white/10 rounded-full transition-colors"
              >
                <FiX size={24} />
              </button>
            </div>

            {/* Cart Items (Scrollable) */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {cartItems.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-gray-400">
                  <FiShoppingBag size={48} className="mb-4 opacity-20" />
                  <p>Your cart is currently empty.</p>
                </div>
              ) : (
                cartItems.map((item) => (
                  <div key={item._id} className="flex gap-4">
                    <div className="w-20 h-20 rounded-xl bg-gray-900 border border-white/5 overflow-hidden flex-shrink-0">
                      <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <h3 className="text-white font-medium line-clamp-1">{item.title}</h3>
                        <p className="text-blue-400 font-bold text-sm">₹{item.price.toLocaleString('en-IN')}</p>
                      </div>
                      <div className="flex items-center justify-between mt-2">
                        <div className="flex items-center border border-white/10 rounded-lg bg-black/50">
                          <button onClick={() => dispatch(decreaseCart(item))} className="p-1.5 text-gray-400 hover:text-white">
                            <FiMinus size={14} />
                          </button>
                          <span className="w-6 text-center text-white text-xs">{item.cartQuantity}</span>
                          <button onClick={() => dispatch(addToCart(item))} className="p-1.5 text-gray-400 hover:text-white">
                            <FiPlus size={14} />
                          </button>
                        </div>
                        <button onClick={() => dispatch(removeFromCart(item))} className="text-red-500 hover:text-red-400 p-1">
                          <FiTrash2 size={16} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Footer / Checkout */}
            {cartItems.length > 0 && (
              <div className="p-6 border-t border-white/10 bg-gray-900/50">
                <div className="flex justify-between items-center mb-6">
                  <span className="text-gray-400">Subtotal</span>
                  <span className="text-2xl font-bold text-white">₹{cartTotal.toLocaleString('en-IN')}</span>
                </div>
                <button 
                  onClick={handleProceedToCheckout}
                  className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl transition-colors shadow-[0_0_15px_rgba(59,130,246,0.3)]"
                >
                  Proceed to Checkout
                </button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default CartDrawer;