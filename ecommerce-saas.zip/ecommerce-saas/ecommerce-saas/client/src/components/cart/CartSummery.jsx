const CartSummary = ({ total }) => {
  return (
    <div>
      <h2>Total: ₹ {total}</h2>
    </div>
  )
}

export default CartSummary