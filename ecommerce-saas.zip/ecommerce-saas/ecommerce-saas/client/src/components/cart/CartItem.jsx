const CartItem = ({ item }) => {
  return (
    <div>
      <h3>{item.title}</h3>

      <p>₹ {item.price}</p>
    </div>
  )
}

export default CartItem