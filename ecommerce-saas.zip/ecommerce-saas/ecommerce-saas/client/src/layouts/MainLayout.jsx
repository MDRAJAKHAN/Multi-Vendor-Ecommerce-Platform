// File: src/layouts/MainLayout.jsx
import { Outlet } from 'react-router-dom';
import Navbar from '../components/common/Navbar';
// import Footer from '../components/common/Footer'; // Uncomment when you build the Footer

const MainLayout = () => {
  return (
    <div className="flex flex-col min-h-screen">
      {/* 1. Global Navbar for all customer routes */}
      <Navbar />

      {/* 2. The Outlet acts as a placeholder. If the user goes to "/shop", 
             the Shop component will be injected right here! */}
      <main className="flex-grow w-full relative">
        <Outlet />
      </main>

      {/* 3. Global Footer (Add this when you are ready) */}
      {/* <Footer /> */}
    </div>
  );
};

export default MainLayout;