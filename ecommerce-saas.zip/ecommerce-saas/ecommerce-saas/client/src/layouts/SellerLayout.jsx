const SellerLayout = ({ children }) => {
  return (
    <div>
      <h1>Seller Panel</h1>

      {children}
    </div>
  )
}

export default SellerLayout