// File: src/layouts/AdminLayout.jsx
import { Outlet, Link, useLocation } from 'react-router-dom';
import { FiHome, FiBox, FiUsers, FiSettings, FiLogOut } from 'react-icons/fi';
import { useDispatch } from 'react-redux';
import { logout } from '../features/auth/authSlice';

const AdminLayout = () => {
  const location = useLocation();
  const dispatch = useDispatch();

  const menuItems = [
    { name: 'Dashboard', icon: FiHome, path: '/admin' },
    { name: 'Manage Products', icon: FiBox, path: '/admin/products' },
    { name: 'Manage Users', icon: FiUsers, path: '/admin/users' },
    { name: 'Settings', icon: FiSettings, path: '/admin/settings' },
  ];

  return (
    <div className="flex h-screen bg-gray-950 overflow-hidden">
      
      {/* Sidebar */}
      <aside className="w-64 bg-gray-900 border-r border-white/5 flex flex-col">
        <div className="p-6 border-b border-white/5">
          <h2 className="text-xl font-black text-white">Admin <span className="text-blue-500">Panel</span></h2>
        </div>
        
        <nav className="flex-1 p-4 space-y-2">
          {menuItems.map((item) => (
            <Link
              key={item.name}
              to={item.path}
              className={`flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${
                location.pathname === item.path ? 'bg-blue-600 text-white shadow-lg' : 'text-gray-400 hover:bg-white/5 hover:text-white'
              }`}
            >
              <item.icon size={18} />
              <span>{item.name}</span>
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t border-white/5">
          <button 
            onClick={() => dispatch(logout())}
            className="flex items-center space-x-3 px-4 py-3 w-full rounded-xl text-sm font-medium text-gray-400 hover:bg-red-500/10 hover:text-red-400 transition-colors"
          >
            <FiLogOut size={18} />
            <span>Logout Account</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-screen overflow-y-auto bg-gray-950">
        <header className="h-20 border-b border-white/5 bg-gray-900/50 backdrop-blur-md px-8 flex items-center justify-between sticky top-0 z-10">
          <h1 className="text-xl font-bold text-white capitalize">
            {location.pathname.split('/').pop() || 'Dashboard'}
          </h1>
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
              A
            </div>
          </div>
        </header>

        {/* This is where the specific admin pages (like ManageProducts.jsx) will inject! */}
        <div className="p-8">
          <Outlet /> 
        </div>
      </main>
      
    </div>
  );
};

export default AdminLayout;