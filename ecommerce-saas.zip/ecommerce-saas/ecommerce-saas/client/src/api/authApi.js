// File: src/api/authApi.js
import API from '../services/axios'; // Import the secure interceptor we built!

// Define all your authentication endpoints in one clean object
const authApi = {
  login: (credentials) => API.post('/auth/login', credentials),
  register: (userData) => API.post('/auth/register', userData),
  verifyToken: () => API.get('/auth/verify'),
};

// THIS is the line Vite was looking for and couldn't find!
export default authApi;