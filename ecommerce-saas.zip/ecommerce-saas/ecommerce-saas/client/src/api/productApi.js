import API from '../services/axios'

export const getProductsAPI = async () => {
  const { data } = await API.get('/products')

  return data
}

export const getSingleProductAPI = async (
  id
) => {
  const { data } = await API.get(
    `/products/${id}`
  )

  return data
}

export const createProductAPI = async (
  productData
) => {
  const { data } = await API.post(
    '/products',
    productData
  )

  return data
}

export const deleteProductAPI = async (
  id
) => {
  const { data } = await API.delete(
    `/products/${id}`
  )

  return data
}