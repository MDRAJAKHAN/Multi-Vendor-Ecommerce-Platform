import { createSlice } from '@reduxjs/toolkit';
import toast from 'react-hot-toast';

const initialState = {
  // Load past orders from local storage so they don't disappear when you refresh!
  orders: localStorage.getItem('userOrders') 
    ? JSON.parse(localStorage.getItem('userOrders')) 
    : [],
};

const orderSlice = createSlice({
  name: 'orders',
  initialState,
  reducers: {
    addOrder(state, action) {
      // Put the newest order at the top of the list (unshift instead of push)
      state.orders.unshift(action.payload);
      // Save it to local storage
      localStorage.setItem('userOrders', JSON.stringify(state.orders));
      toast.success('Order placed successfully!');
    },
    clearOrders(state) {
      state.orders = [];
      localStorage.removeItem('userOrders');
    }
  },
});

export const { addOrder, clearOrders } = orderSlice.actions;
export default orderSlice.reducer;