import { createAsyncThunk } from '@reduxjs/toolkit';
import API from '../../services/axios'; // This is the Axios file we made earlier!

// 1. LIVE LOGIN THUNK
export const loginUser = createAsyncThunk(
  'auth/login',
  async (credentials, { rejectWithValue }) => {
    try {
      // Sends { email, password } to http://localhost:5000/api/auth/login
      const response = await API.post('/auth/login', credentials);
      
      // Store the real JWT token in local storage so the user stays logged in
      if (response.data.token) {
        localStorage.setItem('token', response.data.token);
      }
      
      return response.data; 
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || "Login failed");
    }
  }
);

// 2. LIVE REGISTER THUNK
export const registerUser = createAsyncThunk(
  'auth/register',
  async (userData, { rejectWithValue }) => {
    try {
      // Sends { name, email, password } to http://localhost:5000/api/auth/register
      const response = await API.post('/auth/register', userData);
      
      if (response.data.token) {
        localStorage.setItem('token', response.data.token);
      }
      
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || "Registration failed");
    }
  }
);

// 3. LIVE SEND OTP THUNK
export const sendOtp = createAsyncThunk(
  'auth/sendOtp',
  async (email, { rejectWithValue }) => {
    try {
      // Make sure this route matches your authRoutes.js!
      const response = await API.post('/auth/send-otp', { email });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || "Failed to send OTP");
    }
  }
);

// 4. LIVE RESET PASSWORD THUNK
export const resetPasswordWithOtp = createAsyncThunk(
  'auth/resetPassword',
  async (resetData, { rejectWithValue }) => {
    try {
      const response = await API.post('/auth/reset-password', resetData);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || "Failed to reset password");
    }
  }
);