import { createSlice } from '@reduxjs/toolkit';
import toast from 'react-hot-toast';
import { mockProducts } from '../../data/mockProducts'; // We use this as seed data!

// This function checks Local Storage first. If it's empty, it loads your mock data!
const loadInitialProducts = () => {
  const saved = localStorage.getItem('globalProducts');
  if (saved) return JSON.parse(saved);
  
  localStorage.setItem('globalProducts', JSON.stringify(mockProducts));
  return mockProducts;
};

const productSlice = createSlice({
  name: 'products',
  initialState: {
    products: loadInitialProducts(),
  },
  reducers: {
    addProduct: (state, action) => {
      // Unshift adds the new product to the VERY TOP of the store
      state.products.unshift(action.payload);
      localStorage.setItem('globalProducts', JSON.stringify(state.products));
      toast.success('Product published live to store!');
    }
  }
});

export const { addProduct } = productSlice.actions;
export default productSlice.reducer;